"""
Tamper-proof wallet module for Datacure.

Coins can ONLY be modified through add_coins() or deduct_coins().
Both functions are atomic, validate inputs, prevent negative balances,
and write an immutable record to wallet_transactions on every call.
The frontend is NEVER trusted for coin values.
"""

# ── Custom exceptions ──────────────────────────────────────────────────────────

class WalletError(Exception):
    """Base class for all wallet errors."""

class InsufficientFundsError(WalletError):
    """Raised when a deduction would take the balance below zero."""

class InvalidAmountError(WalletError):
    """Raised when amount is zero, negative, or not an integer."""


# ── Allowed sources (whitelist) ────────────────────────────────────────────────

ALLOWED_SOURCES = {"data_log", "ad_reward", "redeem", "streak_bonus"}


# ── Core wallet functions ──────────────────────────────────────────────────────

def add_coins(db, user_id: int, amount: int, source: str, detail: str) -> int:
    """
    Atomically credit `amount` coins to `user_id`.

    Args:
        db      : Active SQLite connection (from get_db())
        user_id : Target user
        amount  : Positive integer only — NEVER supplied by the frontend
        source  : Must be in ALLOWED_SOURCES
        detail  : Human-readable description for the audit log

    Returns:
        New coin balance (int)

    Raises:
        InvalidAmountError  if amount <= 0
        WalletError         if source is not whitelisted
    """
    _validate_amount(amount)
    _validate_source(source)

    # Read balance before the change for the audit trail
    row = db.execute("SELECT coins FROM users WHERE id = ?", (user_id,)).fetchone()
    if row is None:
        raise WalletError(f"User {user_id} not found.")
    balance_before = row["coins"]

    # Atomic credit — no condition needed for addition
    db.execute(
        "UPDATE users SET coins = coins + ? WHERE id = ?",
        (amount, user_id)
    )

    balance_after = balance_before + amount

    # Immutable audit record
    db.execute(
        """INSERT INTO wallet_transactions
           (user_id, txn_type, amount, source, detail, balance_before, balance_after)
           VALUES (?, 'credit', ?, ?, ?, ?, ?)""",
        (user_id, amount, source, detail, balance_before, balance_after)
    )

    # Mirror to activity_log for the UI feed
    db.execute(
        """INSERT INTO activity_log (user_id, action, detail, coins_delta)
           VALUES (?, ?, ?, ?)""",
        (user_id, source, detail, amount)
    )

    db.commit()
    return balance_after


def deduct_coins(db, user_id: int, amount: int, source: str, detail: str) -> int:
    """
    Atomically debit `amount` coins from `user_id`.

    The SQL UPDATE uses a WHERE coins >= amount guard so the balance can
    never go negative — even under concurrent requests.

    Args:
        db      : Active SQLite connection (from get_db())
        user_id : Target user
        amount  : Positive integer only — NEVER supplied by the frontend
        source  : Must be in ALLOWED_SOURCES
        detail  : Human-readable description for the audit log

    Returns:
        New coin balance (int)

    Raises:
        InvalidAmountError     if amount <= 0
        WalletError            if source is not whitelisted
        InsufficientFundsError if balance < amount
    """
    _validate_amount(amount)
    _validate_source(source)

    row = db.execute("SELECT coins FROM users WHERE id = ?", (user_id,)).fetchone()
    if row is None:
        raise WalletError(f"User {user_id} not found.")
    balance_before = row["coins"]

    if balance_before < amount:
        raise InsufficientFundsError(
            f"Insufficient balance: need {amount}, have {balance_before}."
        )

    # Atomic debit — WHERE guard prevents negative balance even under race
    result = db.execute(
        "UPDATE users SET coins = coins - ? WHERE id = ? AND coins >= ?",
        (amount, user_id, amount)
    )
    if result.rowcount == 0:
        # Race condition: another request drained coins between our read and write
        raise InsufficientFundsError("Insufficient balance (concurrent update).")

    balance_after = balance_before - amount

    # Immutable audit record
    db.execute(
        """INSERT INTO wallet_transactions
           (user_id, txn_type, amount, source, detail, balance_before, balance_after)
           VALUES (?, 'debit', ?, ?, ?, ?, ?)""",
        (user_id, amount, source, detail, balance_before, balance_after)
    )

    # Mirror to activity_log for the UI feed
    db.execute(
        """INSERT INTO activity_log (user_id, action, detail, coins_delta)
           VALUES (?, ?, ?, ?)""",
        (user_id, source, detail, -amount)
    )

    db.commit()
    return balance_after


def get_balance(db, user_id: int) -> int:
    """Fetch the current balance directly from the DB. Never use cached values."""
    row = db.execute("SELECT coins FROM users WHERE id = ?", (user_id,)).fetchone()
    if row is None:
        raise WalletError(f"User {user_id} not found.")
    return row["coins"]


def get_transactions(db, user_id: int, limit: int = 20):
    """Return the most recent wallet_transactions rows for a user."""
    return db.execute(
        """SELECT * FROM wallet_transactions
           WHERE user_id = ?
           ORDER BY created_at DESC LIMIT ?""",
        (user_id, limit)
    ).fetchall()


# ── Private validators ─────────────────────────────────────────────────────────

def _validate_amount(amount):
    if not isinstance(amount, int) or isinstance(amount, bool):
        raise InvalidAmountError("Amount must be an integer.")
    if amount <= 0:
        raise InvalidAmountError("Amount must be greater than zero.")

def _validate_source(source):
    if source not in ALLOWED_SOURCES:
        raise WalletError(
            f"Invalid coin source '{source}'. Allowed: {ALLOWED_SOURCES}"
        )
