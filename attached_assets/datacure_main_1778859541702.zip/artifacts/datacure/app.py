import os
import base64
import math
import re
import secrets
import time
from datetime import date
from functools import wraps
from flask import (
    Flask, render_template, request, redirect,
    url_for, session, jsonify, g, flash, get_flashed_messages
)
from werkzeug.security import generate_password_hash, check_password_hash
from database import init_db, get_db
from streak import update_streak, STREAK_TARGET, STREAK_BONUS_COINS
from ratelimit import check_rate_limit, rl_key
from wallet import (
    add_coins, deduct_coins, get_balance, get_transactions,
    WalletError, InsufficientFundsError, InvalidAmountError
)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "datacure-dev-secret-2024")
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"]  = "Lax"

# ── Constants ──────────────────────────────────────────────────────────────────
COINS_PER_100MB = 5
COINS_PER_AD    = 10
COINS_PER_RUPEE = 100
MAX_ADS_PER_DAY = 15
MB_PER_REWARD   = 100
FIXED_OTP       = "1234"

# Fixed recharge packs: {amount_inr: coins_required}
REDEEM_PACKS = {15: 1500, 20: 2000}

# ── Operator detection (server-side) ───────────────────────────────────────────
def detect_operator(phone: str) -> str:
    if re.match(r'^(98|99|97)', phone):
        return "Airtel"
    if re.match(r'^(70|71|72)', phone):
        return "Jio"
    return "Unknown"

# ── Phone helpers (base64) ─────────────────────────────────────────────────────
def encode_phone(phone: str) -> str:
    return base64.b64encode(phone.encode()).decode()

def decode_phone(encoded: str) -> str:
    try:
        return base64.b64decode(encoded.encode()).decode()
    except Exception:
        return encoded

# ── DB teardown ────────────────────────────────────────────────────────────────
@app.teardown_appcontext
def close_db(error):
    db = g.pop("db", None)
    if db is not None:
        db.close()

# ── Auth decorator ─────────────────────────────────────────────────────────────
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"), 303)
        return f(*args, **kwargs)
    return decorated

# ── Rate-limit decorator ────────────────────────────────────────────────────────
# Applies a 5-requests/5-second sliding window per (endpoint, user/IP).
# is_api=True  → returns JSON 429 (for AJAX endpoints)
# is_api=False → flashes error + PRG redirect (for form POST endpoints)
def rate_limited(is_api: bool = False, redirect_to: str | None = None,
                 post_only: bool = True):
    """
    Sliding-window rate limiter: 5 requests per 5 seconds per (endpoint, user/IP).

    post_only=True  — only count POST requests (leave GET page-loads unrestricted).
    is_api=True     — rejected requests return JSON 429.
    is_api=False    — rejected requests flash a message and do a PRG redirect.
    """
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if post_only and request.method != "POST":
                return f(*args, **kwargs)
            uid  = session.get("user_id", request.remote_addr)
            key  = rl_key(f.__name__, uid)
            allowed, retry_after = check_rate_limit(session, key)
            if not allowed:
                msg = f"Too many requests. Please wait {retry_after}s."
                if is_api:
                    return jsonify({"success": False, "ok": False,
                                    "error": msg}), 429
                flash(msg, "error")
                dest = url_for(redirect_to) if redirect_to else (
                    request.referrer or url_for("dashboard"))
                return redirect(dest, 303)
            return f(*args, **kwargs)
        return decorated
    return decorator

# ── Helper: fetch user row ─────────────────────────────────────────────────────
def get_user(user_id):
    return get_db().execute(
        "SELECT * FROM users WHERE id = ?", (user_id,)
    ).fetchone()

# ── Validation helpers ─────────────────────────────────────────────────────────
def validate_name(name):
    if not name:            return "Name is required."
    if len(name) < 3:       return "Name must be at least 3 characters."
    return None

def validate_phone(phone):
    if not phone:                              return "Phone number is required."
    if not phone.isdigit() or len(phone) != 10: return "Phone must be exactly 10 digits."
    return None

def validate_password(password):
    if not password:         return "Password is required."
    if len(password) < 6:   return "Password must be at least 6 characters."
    return None

# ── Routes: Root ───────────────────────────────────────────────────────────────
@app.route("/")
def index():
    if "user_id" in session:
        return redirect(url_for("dashboard"), 303)
    return redirect(url_for("login"), 303)

# ── Routes: Register ───────────────────────────────────────────────────────────
@app.route("/register", methods=["GET", "POST"])
@rate_limited(redirect_to="register")
def register():
    if "user_id" in session:
        return redirect(url_for("dashboard"), 303)

    if request.method == "POST":
        name     = request.form.get("name",     "").strip()
        phone    = request.form.get("phone",    "").strip()
        password = request.form.get("password", "").strip()
        otp      = request.form.get("otp",      "").strip()

        err = validate_name(name) or validate_phone(phone) or validate_password(password)
        if err:
            flash(err, "error")
            return redirect(url_for("register"), 303)

        if otp != FIXED_OTP:
            flash("Invalid OTP", "error")
            return redirect(url_for("register"), 303)

        encoded_phone = encode_phone(phone)
        db = get_db()
        if db.execute("SELECT id FROM users WHERE phone = ?", (encoded_phone,)).fetchone():
            flash("User already exists", "error")
            return redirect(url_for("register"), 303)

        pw_hash = generate_password_hash(password)
        db.execute(
            "INSERT INTO users (name, phone, password_hash, coins) VALUES (?, ?, ?, 0)",
            (name, encoded_phone, pw_hash)
        )
        db.commit()
        user = db.execute("SELECT id FROM users WHERE phone = ?", (encoded_phone,)).fetchone()
        session.clear()
        session["user_id"] = user["id"]
        return redirect(url_for("dashboard"), 303)

    error = None
    for cat, msg in get_flashed_messages(with_categories=True):
        if cat == "error":
            error = msg
    return render_template("register.html", error=error)

# ── Routes: Login ──────────────────────────────────────────────────────────────
@app.route("/login", methods=["GET", "POST"])
@rate_limited(redirect_to="login")
def login():
    if "user_id" in session:
        return redirect(url_for("dashboard"), 303)

    if request.method == "POST":
        phone    = request.form.get("phone",    "").strip()
        password = request.form.get("password", "").strip()

        err = validate_phone(phone)
        if err:
            flash(err, "error")
            return redirect(url_for("login"), 303)

        encoded_phone = encode_phone(phone)
        db   = get_db()
        user = db.execute("SELECT * FROM users WHERE phone = ?", (encoded_phone,)).fetchone()

        if not user:
            flash("No account found with this number.", "error")
            return redirect(url_for("login"), 303)
        if not check_password_hash(user["password_hash"], password):
            flash("Wrong password", "error")
            return redirect(url_for("login"), 303)

        session.clear()
        session["user_id"] = user["id"]
        return redirect(url_for("dashboard"), 303)

    error = None
    for cat, msg in get_flashed_messages(with_categories=True):
        if cat == "error":
            error = msg
    return render_template("login.html", error=error)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"), 303)

# ── Routes: Dashboard ──────────────────────────────────────────────────────────
@app.route("/dashboard")
@login_required
def dashboard():
    db   = get_db()
    uid  = session["user_id"]

    # ── Update streak first (no-op if already updated today) ──
    streak_info = update_streak(db, uid)

    user = get_user(uid)   # re-fetch after streak may have changed coins/streak

    total_mb = db.execute(
        "SELECT COALESCE(SUM(mb_saved), 0) as total FROM data_logs WHERE user_id = ?",
        (uid,)
    ).fetchone()["total"]

    today     = date.today().isoformat()
    ads_today = db.execute(
        "SELECT COUNT(*) as cnt FROM ad_rewards WHERE user_id = ? AND reward_date = ?",
        (uid, today)
    ).fetchone()["cnt"]

    recent = db.execute(
        "SELECT * FROM activity_log WHERE user_id = ? ORDER BY created_at DESC LIMIT 10",
        (uid,)
    ).fetchall()

    redemptions = db.execute(
        "SELECT * FROM redemptions WHERE user_id = ? ORDER BY created_at DESC LIMIT 5",
        (uid,)
    ).fetchall()

    # Always read balance fresh from DB, never from session/cache
    coins          = get_balance(db, uid)
    rupees_balance = coins / COINS_PER_RUPEE

    return render_template(
        "dashboard.html",
        user=user,
        total_mb=total_mb,
        ads_today=ads_today,
        max_ads=MAX_ADS_PER_DAY,
        recent=recent,
        redemptions=redemptions,
        rupees_balance=rupees_balance,
        coins_per_rupee=COINS_PER_RUPEE,
        decode_phone=decode_phone,
        streak_info=streak_info,
    )

# ── Routes: Log Data (page) ────────────────────────────────────────────────────
@app.route("/log-data", methods=["GET"])
@login_required
def log_data():
    token = secrets.token_hex(16)
    session["log_token"] = token
    user = get_user(session["user_id"])
    return render_template(
        "log_data.html",
        coins_per_100mb=COINS_PER_100MB,
        mb_per_reward=MB_PER_REWARD,
        submit_token=token,
        user=user,
    )

# ── API: Log Data (AJAX) — all coin logic via wallet ──────────────────────────
@app.route("/api/log-data", methods=["POST"])
@login_required
@rate_limited(is_api=True)
def api_log_data():
    data    = request.get_json(silent=True) or {}
    token   = data.get("token", "")
    user_id = session["user_id"]

    if not token or token != session.get("log_token"):
        return jsonify({"success": False, "error": "Duplicate or invalid submission."}), 400
    session.pop("log_token", None)

    raw_mb = data.get("mb_saved")
    try:
        mb_saved = int(raw_mb)
    except (TypeError, ValueError):
        return jsonify({"success": False, "error": "MB value must be a whole number."}), 400

    if mb_saved <= 0:
        return jsonify({"success": False, "error": "Value must be at least 1 MB."}), 400
    if mb_saved > 2000:
        return jsonify({"success": False, "error": "Maximum is 2000 MB per submission."}), 400

    # Coin calculation is server-side only — floor division, no decimals
    coins_earned = math.floor(mb_saved / 100) * COINS_PER_100MB

    db = get_db()

    # Record the data log first (before wallet so both are in same implicit txn)
    db.execute(
        "INSERT INTO data_logs (user_id, mb_saved, coins_earned) VALUES (?, ?, ?)",
        (user_id, mb_saved, coins_earned)
    )

    # Credit via wallet — raises on any issue, logs to wallet_transactions
    if coins_earned > 0:
        new_balance = add_coins(
            db, user_id, coins_earned,
            source="data_log",
            detail=f"Logged {mb_saved} MB saved"
        )
    else:
        db.commit()
        new_balance = get_balance(db, user_id)

    # Fresh token for next submission
    new_token = secrets.token_hex(16)
    session["log_token"] = new_token

    return jsonify({
        "success":     True,
        "new_coins":   coins_earned,
        "total_coins": new_balance,
        "mb_saved":    mb_saved,
        "next_token":  new_token,
    })

# ── API: Ad Start — issues server-timestamped watch token ─────────────────────
@app.route("/api/ad/start", methods=["POST"])
@login_required
@rate_limited(is_api=True)
def api_ad_start():
    today = date.today().isoformat()
    db    = get_db()
    uid   = session["user_id"]

    ads_today = db.execute(
        "SELECT COUNT(*) as cnt FROM ad_rewards WHERE user_id=? AND reward_date=?",
        (uid, today)
    ).fetchone()["cnt"]

    if ads_today >= MAX_ADS_PER_DAY:
        return jsonify({
            "ok": False, "reason": "limit",
            "message": f"Daily limit of {MAX_ADS_PER_DAY} ads reached. Come back tomorrow!"
        })

    # Always reset timer — covers the refresh-during-ad case.
    # If user refreshes and calls /start again, the clock restarts from now,
    # so they must wait a full 15 s again before /claim will succeed.
    watch_token = secrets.token_hex(16)
    session["watch_token"]      = watch_token
    session["watch_started_at"] = time.time()

    return jsonify({
        "ok":       True,
        "token":    watch_token,
        "duration": 15,
        "ads_remaining": MAX_ADS_PER_DAY - ads_today,
    })

# ── API: Ad Claim — validates server-side elapsed time before crediting ────────
@app.route("/api/ad/claim", methods=["POST"])
@login_required
@rate_limited(is_api=True)
def api_ad_claim():
    data  = request.get_json(silent=True) or {}
    token = data.get("token", "")
    uid   = session["user_id"]

    # ── Token validation ──
    stored_token = session.get("watch_token")
    if not token or token != stored_token:
        return jsonify({"ok": False,
                        "message": "Invalid or expired watch token."}), 400

    # ── Server-side time guard (refresh attack = new /start = timer reset) ──
    started_at = session.get("watch_started_at", 0)
    elapsed    = time.time() - started_at
    if elapsed < 15:
        remaining = int(15 - elapsed) + 1
        return jsonify({"ok": False,
                        "message": f"Ad not fully watched. {remaining}s remaining."}), 400

    # ── Daily limit double-check ──
    today = date.today().isoformat()
    db    = get_db()
    ads_today = db.execute(
        "SELECT COUNT(*) as cnt FROM ad_rewards WHERE user_id=? AND reward_date=?",
        (uid, today)
    ).fetchone()["cnt"]

    if ads_today >= MAX_ADS_PER_DAY:
        session.pop("watch_token", None)
        session.pop("watch_started_at", None)
        return jsonify({"ok": False, "reason": "limit",
                        "message": "Daily ad limit already reached."}), 400

    # ── Consume token immediately — prevents double-claim ──
    session.pop("watch_token", None)
    session.pop("watch_started_at", None)

    # ── Record ad view + credit via tamper-proof wallet ──
    db.execute(
        "INSERT INTO ad_rewards (user_id, reward_date) VALUES (?, ?)",
        (uid, today)
    )
    new_balance = add_coins(
        db, uid, COINS_PER_AD,
        source="ad_reward",
        detail="Watched reward ad"
    )

    return jsonify({
        "ok":            True,
        "message":       f"You earned {COINS_PER_AD} coins!",
        "new_balance":   new_balance,
        "ads_today":     ads_today + 1,
        "ads_remaining": MAX_ADS_PER_DAY - (ads_today + 1),
    })

# ── Routes: Rewards page ───────────────────────────────────────────────────────
@app.route("/rewards")
@login_required
def rewards():
    today   = date.today().isoformat()
    db      = get_db()
    uid     = session["user_id"]
    user    = get_user(uid)
    ads_today = db.execute(
        "SELECT COUNT(*) as cnt FROM ad_rewards WHERE user_id = ? AND reward_date = ?",
        (uid, today)
    ).fetchone()["cnt"]

    return render_template(
        "rewards.html",
        user=user,
        ads_today=ads_today,
        max_ads=MAX_ADS_PER_DAY,
        coins_per_ad=COINS_PER_AD,
    )

# ── Routes: Redeem — fixed packs, operator detection, deduct-first ─────────────
@app.route("/redeem", methods=["GET", "POST"])
@login_required
@rate_limited(redirect_to="redeem")
def redeem():
    db  = get_db()
    uid = session["user_id"]

    if request.method == "POST":
        # ── Pack validation (only ₹15 or ₹20 accepted) ──
        try:
            amount_inr = int(request.form.get("amount_inr", 0))
        except (ValueError, TypeError):
            flash("Invalid pack selection.", "error")
            return redirect(url_for("redeem"), 303)

        if amount_inr not in REDEEM_PACKS:
            flash("Invalid pack. Choose ₹15 or ₹20.", "error")
            return redirect(url_for("redeem"), 303)

        coins_needed = REDEEM_PACKS[amount_inr]

        # ── Phone validation ──
        phone = request.form.get("phone", "").strip()
        if not phone.isdigit() or len(phone) != 10:
            flash("Invalid mobile number. Must be exactly 10 digits.", "error")
            return redirect(url_for("redeem"), 303)

        # ── Operator detection (server-side) ──
        operator = detect_operator(phone)

        # ── Fresh balance check — never trust frontend ──
        current_balance = get_balance(db, uid)
        if coins_needed > current_balance:
            flash(
                f"Not enough coins. ₹{amount_inr} requires {coins_needed} coins "
                f"but your balance is {current_balance}.",
                "error"
            )
            return redirect(url_for("redeem"), 303)

        # ── Deduct BEFORE marking success ──
        try:
            new_balance = deduct_coins(
                db, uid, coins_needed,
                source="redeem",
                detail=f"₹{amount_inr} {operator} recharge to {phone}"
            )
        except InsufficientFundsError as e:
            flash(f"Transaction failed — {e}", "error")
            return redirect(url_for("redeem"), 303)

        # ── Record redemption ──
        db.execute(
            "INSERT INTO redemptions (user_id, coins_spent, amount_inr, phone) VALUES (?, ?, ?, ?)",
            (uid, coins_needed, amount_inr, phone)
        )
        db.commit()

        flash(
            f"RECHARGE_SUCCESS|{amount_inr}|{phone}|{operator}|{coins_needed}|{new_balance}",
            "success"
        )
        return redirect(url_for("redeem"), 303)

    # GET
    error = success_data = None
    for cat, msg in get_flashed_messages(with_categories=True):
        if cat == "error":
            error = msg
        if cat == "success" and msg.startswith("RECHARGE_SUCCESS|"):
            parts = msg.split("|")
            success_data = {
                "amount_inr":   parts[1],
                "phone":        parts[2],
                "operator":     parts[3],
                "coins_spent":  parts[4],
                "new_balance":  parts[5],
            }

    user = get_user(uid)
    return render_template(
        "redeem.html",
        error=error,
        success_data=success_data,
        user=user,
        redeem_packs=REDEEM_PACKS,
        coins_per_rupee=COINS_PER_RUPEE,
        decode_phone=decode_phone,
    )

# ── API: Balance — always fresh from DB, never cached ─────────────────────────
@app.route("/api/balance")
@login_required
def api_balance():
    db      = get_db()
    uid     = session["user_id"]
    coins   = get_balance(db, uid)
    rupees  = round(coins / COINS_PER_RUPEE, 2)
    return jsonify({"coins": coins, "rupees": rupees})

# ── API: Wallet transactions (audit log) ───────────────────────────────────────
@app.route("/api/wallet/transactions")
@login_required
def api_wallet_transactions():
    db  = get_db()
    uid = session["user_id"]
    try:
        limit = min(int(request.args.get("limit", 20)), 100)
    except (ValueError, TypeError):
        limit = 20
    txns = get_transactions(db, uid, limit)
    return jsonify([dict(row) for row in txns])

# ── Init & run ─────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    init_db()
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
