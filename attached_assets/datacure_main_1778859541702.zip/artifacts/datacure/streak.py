"""
Streak tracking module for Datacure.

Logic (exact per spec):
    IF today == last_active_date  → do nothing (already counted)
    IF yesterday == last_active_date → streak += 1
    ELSE                           → streak = 1 (reset)

Bonus:
    +20 coins granted once per day when the streak increments.
    (Stored in streak_bonus_date to prevent double-granting.)
"""

from datetime import date, timedelta

STREAK_TARGET      = 7    # days shown on progress bar milestone
STREAK_BONUS_COINS = 20   # coins awarded each day the streak increments


def update_streak(db, user_id: int) -> dict:
    """
    Call once per session/page-visit.  Safe to call multiple times — the
    today == last_active_date guard makes subsequent calls no-ops.

    Returns a dict:
        streak        (int)  — current streak after update
        is_new_day    (bool) — True if streak was actually updated today
        bonus_granted (bool) — True if +20 bonus coins were credited
        bonus_coins   (int)  — coins awarded (0 or STREAK_BONUS_COINS)
        progress      (int)  — 0-100, position within current 7-day window
        days_to_target(int)  — days left to next 7-day milestone
    """
    today     = date.today().isoformat()
    yesterday = (date.today() - timedelta(days=1)).isoformat()

    user = db.execute(
        "SELECT streak, last_active_date, streak_bonus_date FROM users WHERE id=?",
        (user_id,)
    ).fetchone()

    streak = user["streak"] or 0
    last   = user["last_active_date"]

    # ── Already updated today — return current state, no changes ──────────────
    if last == today:
        return _result(streak, is_new_day=False,
                       bonus_granted=False, bonus_coins=0)

    # ── Determine new streak value ─────────────────────────────────────────────
    if last == yesterday:
        streak += 1          # consecutive day → extend
    else:
        streak = 1           # gap or first day → reset to 1

    # ── Persist streak + last_active_date ─────────────────────────────────────
    db.execute(
        "UPDATE users SET streak=?, last_active_date=? WHERE id=?",
        (streak, today, user_id)
    )

    # ── Streak bonus: +20 coins once per day when streak increments ───────────
    bonus_granted = False
    bonus_coins   = 0
    if user["streak_bonus_date"] != today:
        # Import here to avoid circular dependency at module load
        from wallet import add_coins
        add_coins(
            db, user_id, STREAK_BONUS_COINS,
            source="streak_bonus",
            detail=f"Day-{streak} streak bonus"
        )
        db.execute(
            "UPDATE users SET streak_bonus_date=? WHERE id=?",
            (today, user_id)
        )
        bonus_granted = True
        bonus_coins   = STREAK_BONUS_COINS

    db.commit()
    return _result(streak, is_new_day=True,
                   bonus_granted=bonus_granted, bonus_coins=bonus_coins)


def get_streak_info(db, user_id: int) -> dict:
    """Read-only streak info without updating anything."""
    user   = db.execute(
        "SELECT streak, last_active_date FROM users WHERE id=?", (user_id,)
    ).fetchone()
    streak = user["streak"] or 0
    return _result(streak, is_new_day=False, bonus_granted=False, bonus_coins=0)


# ── Private helper ─────────────────────────────────────────────────────────────

def _result(streak, *, is_new_day, bonus_granted, bonus_coins):
    within_window   = streak % STREAK_TARGET          # 0-6
    days_to_target  = STREAK_TARGET - within_window   # 1-7
    if within_window == 0 and streak > 0:
        # Just hit an exact milestone — show full bar briefly
        days_to_target = STREAK_TARGET
    progress = int((within_window / STREAK_TARGET) * 100)
    return {
        "streak":         streak,
        "is_new_day":     is_new_day,
        "bonus_granted":  bonus_granted,
        "bonus_coins":    bonus_coins,
        "progress":       progress,
        "days_to_target": days_to_target,
        "target":         STREAK_TARGET,
        "bonus_coins_per_day": STREAK_BONUS_COINS,
    }
