import sqlite3
import os
from flask import g

DB_PATH = os.path.join(os.path.dirname(__file__), "datacure.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT    NOT NULL DEFAULT '',
    phone         TEXT    NOT NULL UNIQUE,
    password_hash TEXT    NOT NULL,
    coins         INTEGER NOT NULL DEFAULT 0 CHECK (coins >= 0),
    created_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS wallet_transactions (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id        INTEGER NOT NULL REFERENCES users(id),
    txn_type       TEXT    NOT NULL CHECK (txn_type IN ('credit', 'debit')),
    amount         INTEGER NOT NULL CHECK (amount > 0),
    source         TEXT    NOT NULL,
    detail         TEXT    NOT NULL DEFAULT '',
    balance_before INTEGER NOT NULL,
    balance_after  INTEGER NOT NULL CHECK (balance_after >= 0),
    created_at     TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS data_logs (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER NOT NULL REFERENCES users(id),
    mb_saved     INTEGER NOT NULL,
    coins_earned INTEGER NOT NULL,
    created_at   TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS ad_rewards (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id),
    reward_date TEXT    NOT NULL,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS redemptions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id),
    coins_spent INTEGER NOT NULL,
    amount_inr  INTEGER NOT NULL,
    phone       TEXT    NOT NULL,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS activity_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id),
    action      TEXT    NOT NULL,
    detail      TEXT    NOT NULL DEFAULT '',
    coins_delta INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);
"""

# Indexes for fast wallet_transactions lookups
INDEXES = """
CREATE INDEX IF NOT EXISTS idx_wallet_txn_user
    ON wallet_transactions(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_activity_user
    ON activity_log(user_id, created_at DESC);
"""

def get_db():
    if "db" not in g:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        g.db = conn
    return g.db

def _migrate(conn):
    """Apply incremental schema changes to existing databases."""
    cols = {row[1] for row in conn.execute("PRAGMA table_info(users)").fetchall()}

    if "name" not in cols:
        conn.execute("ALTER TABLE users ADD COLUMN name TEXT NOT NULL DEFAULT ''")

    # Streak columns (added in prompt-7)
    if "streak" not in cols:
        conn.execute("ALTER TABLE users ADD COLUMN streak INTEGER NOT NULL DEFAULT 0")
    if "last_active_date" not in cols:
        conn.execute("ALTER TABLE users ADD COLUMN last_active_date TEXT DEFAULT NULL")
    if "streak_bonus_date" not in cols:
        conn.execute("ALTER TABLE users ADD COLUMN streak_bonus_date TEXT DEFAULT NULL")

    # Add CHECK constraint guard to coins column (cannot be done via ALTER TABLE
    # in SQLite, but the wallet functions enforce this at the application level).

    # Add wallet_transactions if upgrading from pre-wallet schema
    tables = {
        row[0] for row in
        conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
    }
    if "wallet_transactions" not in tables:
        conn.executescript("""
            CREATE TABLE wallet_transactions (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id        INTEGER NOT NULL REFERENCES users(id),
                txn_type       TEXT    NOT NULL CHECK (txn_type IN ('credit', 'debit')),
                amount         INTEGER NOT NULL CHECK (amount > 0),
                source         TEXT    NOT NULL,
                detail         TEXT    NOT NULL DEFAULT '',
                balance_before INTEGER NOT NULL,
                balance_after  INTEGER NOT NULL CHECK (balance_after >= 0),
                created_at     TEXT    NOT NULL DEFAULT (datetime('now'))
            );
        """)

    conn.commit()

def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    conn.executescript(INDEXES)
    _migrate(conn)
    conn.commit()
    conn.close()
