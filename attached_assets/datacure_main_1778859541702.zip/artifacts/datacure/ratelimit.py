"""
Sliding-window rate limiter — stored entirely in the Flask session cookie.

Design:
  - One list of UNIX timestamps per (endpoint, user/IP) key stored in session.
  - On every call: prune timestamps older than WINDOW, count remaining.
  - If count >= MAX  →  blocked (False)
  - Otherwise        →  append now, return True (allowed)

Storage cost: at most MAX floats (8 bytes each) per key — negligible.
No Redis, no DB, no shared state required.
"""

import time

RATE_LIMIT_MAX    = 5     # requests
RATE_LIMIT_WINDOW = 5.0   # seconds


def check_rate_limit(
    session_obj,
    key: str,
    max_req: int   = RATE_LIMIT_MAX,
    window: float  = RATE_LIMIT_WINDOW,
) -> tuple[bool, float]:
    """
    Check and update the sliding-window rate limit for `key`.

    Returns:
        (allowed: bool, retry_after: float)
        retry_after is 0.0 when allowed, or seconds until oldest entry expires.
    """
    now    = time.time()
    cutoff = now - window

    # Prune expired timestamps (O(n), n ≤ max_req — always tiny)
    ts = [t for t in session_obj.get(key, []) if t > cutoff]

    if len(ts) >= max_req:
        # Return how long until the oldest entry falls out of the window
        retry_after = round(window - (now - ts[0]) + 0.1, 1)
        session_obj[key] = ts          # persist pruned list (no new entry)
        return False, retry_after

    ts.append(now)
    session_obj[key] = ts
    return True, 0.0


def rl_key(endpoint_name: str, user_id) -> str:
    """Build a namespaced session key for this endpoint + user."""
    return f"_rl_{endpoint_name}_{user_id}"
