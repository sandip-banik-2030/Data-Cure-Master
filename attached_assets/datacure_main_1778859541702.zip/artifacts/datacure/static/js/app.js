/* Datacure — global wallet-aware JS
 *
 * Balance is ALWAYS fetched from the server.
 * The frontend never computes or stores a coin value as truth.
 */

// ── Balance selectors ───────────────────────────────────────────────────────
const BALANCE_SELECTORS = [
  '#nav-coins',
  '#dash-coins',
  '#side-balance',
  '#reward-balance',
];

let _lastCoins = null;  // track previous value to detect increase

// ── Fetch fresh balance; only touch DOM when value actually changes ──────────
async function fetchBalance() {
  try {
    const res = await fetch('/api/balance', { credentials: 'same-origin' });
    if (!res.ok) return null;
    const { coins, rupees } = await res.json();

    const increased = _lastCoins !== null && coins > _lastCoins;

    BALANCE_SELECTORS.forEach(sel => {
      const el = document.querySelector(sel);
      if (!el) return;

      const newText = sel === '#nav-coins' ? '🪙 ' + coins : String(coins);
      if (el.textContent === newText) return;   // no-op if unchanged

      el.textContent = newText;

      if (increased) {
        // Restart glow animation cleanly
        el.classList.remove('coin-glow');
        void el.offsetWidth;
        el.classList.add('coin-glow');
        el.addEventListener('animationend',
          () => el.classList.remove('coin-glow'), { once: true });
      }
    });

    document.querySelectorAll('[data-rupee-value]').forEach(el => {
      const t = '₹' + rupees;
      if (el.textContent !== t) el.textContent = t;
    });

    _lastCoins = coins;
    return coins;
  } catch (_) {
    return null;
  }
}

// ── Wallet guard: no client-side coin mutation ──────────────────────────────
window.__walletSetCoins = undefined;

// ── Page loader bar ─────────────────────────────────────────────────────────
function showPageLoader() {
  let bar = document.getElementById('page-loader');
  if (!bar) {
    bar = document.createElement('div');
    bar.id = 'page-loader';
    document.body.prepend(bar);
  }
  bar.className = 'page-loader-active';
  bar.style.width = '0%';
  requestAnimationFrame(() => requestAnimationFrame(() => { bar.style.width = '70%'; }));
}

function hidePageLoader() {
  const bar = document.getElementById('page-loader');
  if (!bar) return;
  bar.style.width = '100%';
  setTimeout(() => {
    bar.className = 'page-loader-done';
    setTimeout(() => { bar.className = ''; bar.style.width = '0%'; }, 350);
  }, 120);
}

// ── Button loading state ─────────────────────────────────────────────────────
function setButtonLoading(btn) {
  if (!btn || btn.disabled) return;
  btn.disabled = true;
  btn.dataset.origHtml = btn.innerHTML;
  const label = btn.dataset.loadingText || 'Please wait…';
  btn.innerHTML = '<span class="btn-spinner" aria-hidden="true"></span>' + label;
}

// ── DOMContentLoaded ─────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {

  // ── Initial balance fetch ──────────────────────────────────────────────────
  if (document.querySelector('#nav-coins')) {
    fetchBalance();
  }

  // ── Page loader on internal navigation links ───────────────────────────────
  document.querySelectorAll('a[href]').forEach(link => {
    const href = link.getAttribute('href');
    if (!href || href.startsWith('#') || href.startsWith('javascript')) return;
    link.addEventListener('click', e => {
      if (e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
      showPageLoader();
    });
  });

  // ── Form submit → spinner on the submit button ─────────────────────────────
  document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', () => {
      const btn = form.querySelector('button[type="submit"], input[type="submit"], button:not([type])');
      if (btn) {
        setButtonLoading(btn);
        showPageLoader();
      }
    });
  });

  // ── Touch tap scale for mobile (CSS :active handles desktop) ──────────────
  const tapTargets = document.querySelectorAll('.btn, .action-btn, .preset-btn');
  tapTargets.forEach(el => {
    el.addEventListener('touchstart', () => el.classList.add('btn-tapped'),   { passive: true });
    el.addEventListener('touchend',   () => setTimeout(() => el.classList.remove('btn-tapped'), 130));
    el.addEventListener('touchcancel',() => el.classList.remove('btn-tapped'));
  });

});

// ── Periodic refresh every 60 s ─────────────────────────────────────────────
setInterval(() => {
  if (document.querySelector('#nav-coins')) fetchBalance();
}, 60_000);
